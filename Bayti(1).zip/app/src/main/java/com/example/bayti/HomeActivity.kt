package com.example.bayti

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

class HomeActivity : AppCompatActivity() {

    private val handler = Handler(Looper.getMainLooper())
    private val entries = mutableListOf<AppEntry>()
    private var editMode = false

    private lateinit var recycler: RecyclerView
    private lateinit var clockTv: TextView
    private lateinit var dateTv: TextView
    private lateinit var prayerTv: TextView
    private lateinit var weatherTv: TextView
    private lateinit var hintTv: TextView

    private data class AppEntry(val label: String, val pkg: String, val banner: Drawable?, val icon: Drawable?, val launch: Intent)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        clockTv = findViewById(R.id.clock)
        dateTv = findViewById(R.id.date)
        prayerTv = findViewById(R.id.prayer)
        weatherTv = findViewById(R.id.weather)
        hintTv = findViewById(R.id.hint)
        recycler = findViewById(R.id.appsRow)
        recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        recycler.clipChildren = false
        recycler.clipToPadding = false

        loadApps()
        recycler.adapter = AppsAdapter()

        findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
        findViewById<View>(R.id.btnWifi).setOnClickListener {
            try { startActivity(Intent("android.settings.WIFI_SETTINGS")) } catch (e: Exception) {}
        }

        startClock()
        refreshWeather()
        refreshPrayer()

        recycler.post {
            (recycler.layoutManager as LinearLayoutManager).findViewByPosition(0)?.requestFocus()
        }
    }

    // ---------- التطبيقات ----------
    private fun loadApps() {
        val pm = packageManager
        val found = LinkedHashMap<String, AppEntry>()
        val cats = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
        for (cat in cats) {
            val qi = Intent(Intent.ACTION_MAIN).addCategory(cat)
            for (ri in pm.queryIntentActivities(qi, 0)) {
                val pkg = ri.activityInfo.packageName
                if (pkg == packageName || found.containsKey(pkg)) continue
                val cn = android.content.ComponentName(pkg, ri.activityInfo.name)
                val banner = try { pm.getActivityBanner(cn) ?: pm.getApplicationBanner(ri.activityInfo.applicationInfo) } catch (e: Exception) { null }
                val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
                val label = ri.loadLabel(pm)?.toString() ?: pkg
                val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
                found[pkg] = AppEntry(label, pkg, banner, icon, launch)
            }
        }
        entries.clear()
        entries.addAll(found.values)
        // تطبيق ترتيب محفوظ
        val order = Prefs.sp(this).getString("order", "") ?: ""
        if (order.isNotBlank()) {
            val rank = order.split(",").mapIndexed { i, p -> p to i }.toMap()
            entries.sortBy { rank[it.pkg] ?: Int.MAX_VALUE }
        }
    }

    private fun saveOrder() =
        Prefs.sp(this).edit().putString("order", entries.joinToString(",") { it.pkg }).apply()

    private fun setEdit(b: Boolean) {
        editMode = b
        hintTv.visibility = if (b) View.VISIBLE else View.GONE
    }

    private inner class AppsAdapter : RecyclerView.Adapter<AppsAdapter.H>() {
        inner class H(v: View) : RecyclerView.ViewHolder(v) {
            val img: ImageView = v.findViewById(R.id.tileImg)
            val label: TextView = v.findViewById(R.id.tileLabel)
            val tile: View = v
        }

        override fun onCreateViewHolder(p: ViewGroup, t: Int) =
            H(layoutInflater.inflate(R.layout.item_app, p, false))

        override fun getItemCount() = entries.size

        override fun onBindViewHolder(h: H, pos: Int) {
            val e = entries[pos]
            h.label.text = e.label
            if (e.banner != null) {
                h.img.setImageDrawable(e.banner)
                h.img.scaleType = ImageView.ScaleType.CENTER_CROP
            } else {
                h.img.setImageDrawable(e.icon)
                h.img.scaleType = ImageView.ScaleType.FIT_CENTER
            }
            h.tile.onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                v.animate().cancel()
                v.animate()
                    .scaleX(if (has) 1.14f else 1f)
                    .scaleY(if (has) 1.14f else 1f)
                    .setDuration(160).start()
                v.alpha = if (has) 1f else 0.82f
                v.elevation = if (has) 18f else 4f
            }
            h.tile.setOnClickListener {
                if (!editMode) try { startActivity(e.launch) } catch (ex: Exception) {}
            }
            h.tile.setOnLongClickListener { setEdit(true); true }
            h.tile.setOnKeyListener { _, code, _ ->
                if (!editMode) return@setOnKeyListener false
                when (code) {
                    KeyEvent.KEYCODE_DPAD_LEFT -> { move(pos, -1); true }
                    KeyEvent.KEYCODE_DPAD_RIGHT -> { move(pos, 1); true }
                    KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { setEdit(false); true }
                    else -> true
                }
            }
        }
    }

    private fun move(pos: Int, dir: Int) {
        val to = pos + dir
        if (to < 0 || to >= entries.size) return
        val e = entries.removeAt(pos)
        entries.add(to, e)
        saveOrder()
        recycler.adapter?.notifyItemMoved(pos, to)
        recycler.post { (recycler.layoutManager as LinearLayoutManager).findViewByPosition(to)?.requestFocus() }
    }

    // ---------- الساعة ----------
    private fun startClock() {
        val tick = object : Runnable {
            override fun run() {
                val now = Calendar.getInstance()
                clockTv.text = SimpleDateFormat("HH:mm", Locale("ar")).format(now.time)
                dateTv.text = SimpleDateFormat("EEEE، d MMMM", Locale("ar")).format(now.time)
                handler.postDelayed(this, 20_000)
            }
        }
        handler.post(tick)
    }

    // ---------- الطقس ----------
    private fun refreshWeather() {
        Thread {
            val r = Weather.fetch(this)
            runOnUiThread {
                weatherTv.text = r?.let { "🌡 ${it.temp}° | ${it.city}" } ?: "الطقس غير متاح"
            }
        }.start()
    }

    // ---------- الصلاة ----------
    private fun refreshPrayer() {
        Thread {
            val t = Prayer.fetch(this)
            runOnUiThread {
                if (t == null) {
                    prayerTv.text = "مواقيت الصلاة غير متاحة"
                } else {
                    val (name, at) = Prayer.nextOf(t)
                    val hm = SimpleDateFormat("HH:mm", Locale.US).format(at)
                    prayerTv.text = "الصلاة القادمة: $name — $hm"
                    Prayer.scheduleNext(this, t)
                }
            }
        }.start()
    }

    // ---------- الإعدادات ----------
    private fun showSettings() {
        val opts = arrayOf("ترتيب البلاطات", "مدينة الطقس والصلاة", "إعدادات الواي فاي", "إعدادات الشاشة")
        AlertDialog.Builder(this)
            .setTitle("الإعدادات")
            .setItems(opts) { _, which ->
                when (which) {
                    0 -> setEdit(true)
                    1 -> askCity()
                    2 -> try { startActivity(Intent("android.settings.WIFI_SETTINGS")) } catch (e: Exception) {}
                    3 -> try { startActivity(Intent("android.settings.DISPLAY_SETTINGS")) } catch (e: Exception) {}
                }
            }.show()
    }

    private fun askCity() {
        val box = EditText(this).apply { setText(Prefs.city(this@HomeActivity)) }
        AlertDialog.Builder(this)
            .setTitle("اسم المدينة (بالإنجليزية مثل: Istanbul)")
            .setView(box)
            .setPositiveButton("حفظ") { _, _ ->
                val c = box.text.toString().trim()
                if (c.isNotEmpty()) {
                    Prefs.setCity(this, c)
                    refreshWeather()
                    refreshPrayer()
                }
            }
            .setNegativeButton("إلغاء", null)
            .show()
    }
}
