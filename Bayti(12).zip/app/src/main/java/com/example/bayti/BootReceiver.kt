package com.example.bayti

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        Thread {
            try {
                Prayer.fetch(ctx)?.let { Prayer.scheduleNext(ctx, it) }
            } finally { pending.finish() }
        }.start()
    }
}
