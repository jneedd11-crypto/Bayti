package com.example.bayti

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat

class PrayerAlertReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, intent: Intent) {
        val name = intent.getStringExtra("name") ?: "الصلاة"
        val nm = NotificationManagerCompat.from(ctx)
        nm.createNotificationChannel(
            NotificationChannel("prayer", "تنبيهات الصلاة", NotificationManager.IMPORTANCE_HIGH)
        )
        val open = PendingIntent.getActivity(
            ctx, 0, Intent(ctx, HomeActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(ctx, "prayer")
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("حان الآن وقت صلاة $name 🕌")
            .setContentText("تقبّل الله طاعتكم")
            .setAutoCancel(true)
            .setContentIntent(open)
            .build()
        try { nm.notify(1001, n) } catch (e: SecurityException) {}
        // جدولة الصلاة التالية
        val pending = goAsync()
        Thread {
            try {
                Prayer.fetch(ctx)?.let { Prayer.scheduleNext(ctx, it) }
            } finally { pending.finish() }
        }.start()
    }
}
