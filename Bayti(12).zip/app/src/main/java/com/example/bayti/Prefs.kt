package com.example.bayti

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private const val F = "bayti"
    fun sp(c: Context): SharedPreferences = c.getSharedPreferences(F, 0)
    fun city(c: Context): String = sp(c).getString("city", "Kayseri") ?: "Kayseri"
    fun setCity(c: Context, v: String) = sp(c).edit().putString("city", v).apply()
}
