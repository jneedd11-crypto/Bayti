package com.example.bayti

import android.content.Context
import org.json.JSONObject
import java.net.URL
import java.text.NumberFormat
import java.util.Locale

object Rates {
    data class Result(val usd: Double, val eur: Double, val gold24: Double, val gold21: Double, val time: Long)

    fun fetch(ctx: Context): Result? = try {
        val fx = JSONObject(URL("https://open.er-api.com/v6/latest/USD").readText())
        val rates = fx.getJSONObject("rates")
        val usdTry = rates.getDouble("TRY")
        val eurTry = usdTry / rates.getDouble("EUR")
        val gold = JSONObject(URL("https://api.gold-api.com/price/XAU").readText())
        val gram24 = gold.getDouble("price") / 31.1034768 * usdTry
        val r = Result(usdTry, eurTry, gram24, gram24 * 0.875, System.currentTimeMillis())
        save(ctx, r)
        r
    } catch (e: Exception) {
        cached(ctx)
    }

    private fun save(ctx: Context, r: Result) = Prefs.sp(ctx).edit().apply {
        putLong("r_time", r.time)
        putString("r_usd", r.usd.toString())
        putString("r_eur", r.eur.toString())
        putString("r_g24", r.gold24.toString())
        putString("r_g21", r.gold21.toString())
    }.apply()

    private fun cached(ctx: Context): Result? {
        val sp = Prefs.sp(ctx)
        if (!sp.contains("r_time")) return null
        return try {
            Result(
                sp.getString("r_usd", "0")!!.toDouble(),
                sp.getString("r_eur", "0")!!.toDouble(),
                sp.getString("r_g24", "0")!!.toDouble(),
                sp.getString("r_g21", "0")!!.toDouble(),
                sp.getLong("r_time", 0)
            )
        } catch (e: Exception) { null }
    }

    private val nf = NumberFormat.getNumberInstance(Locale("tr", "TR")).apply { maximumFractionDigits = 2 }
    fun fmt(v: Double): String = nf.format(v)
}
