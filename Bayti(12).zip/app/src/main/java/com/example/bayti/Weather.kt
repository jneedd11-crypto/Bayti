package com.example.bayti

import android.content.Context
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder

object Weather {
    data class Now(val temp: Int, val city: String)

    fun fetch(ctx: Context): Now? {
        val city = Prefs.city(ctx)
        return try {
            val enc = URLEncoder.encode(city, "UTF-8")
            val geo = URL("https://geocoding-api.open-meteo.com/v1/search?name=$enc&count=1").readText()
            val g = JSONObject(geo).getJSONArray("results").getJSONObject(0)
            val lat = g.getDouble("latitude")
            val lon = g.getDouble("longitude")
            val w = URL("https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon&current_weather=true").readText()
            val cw = JSONObject(w).getJSONObject("current_weather")
            Now(cw.getDouble("temperature").toInt(), city).also { save(ctx, it) }
        } catch (e: Exception) {
            cached(ctx)
        }
    }

    private fun save(ctx: Context, n: Now) =
        Prefs.sp(ctx).edit().putInt("w_temp", n.temp).putString("w_city", n.city).apply()

    private fun cached(ctx: Context): Now? {
        val t = Prefs.sp(ctx).getInt("w_temp", Int.MIN_VALUE)
        return if (t == Int.MIN_VALUE) null else Now(t, Prefs.sp(ctx).getString("w_city", "") ?: "")
    }
}
