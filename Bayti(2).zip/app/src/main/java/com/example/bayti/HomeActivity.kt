package com.example.bayti

    import android.animation.ValueAnimator
    import android.content.Intent
    import android.content.pm.PackageManager
    import android.graphics.Bitmap
    import android.graphics.Canvas
    import android.graphics.Color
    import android.graphics.drawable.ColorDrawable
    import android.graphics.drawable.Drawable
    import android.graphics.drawable.GradientDrawable
    import android.os.Bundle
    import android.os.Handler
    import android.os.Looper
    import android.view.Gravity
    import android.view.KeyEvent
    import android.view.View
    import android.view.ViewGroup
    import android.widget.Button
    import android.widget.EditText
    import android.widget.ImageView
    import android.widget.LinearLayout
    import android.widget.TextView
    import androidx.appcompat.app.AlertDialog
    import androidx.appcompat.app.AppCompatActivity
    import androidx.palette.graphics.Palette
    import androidx.recyclerview.widget.LinearLayoutManager
    import androidx.recyclerview.widget.RecyclerView
    import java.text.SimpleDateFormat
    import java.util.Calendar
    import java.util.Locale

    class HomeActivity : AppCompatActivity() {

        private val handler = Handler(Looper.getMainLooper())
        private val entries = mutableListOf<AppEntry>()
        private var editMode = false

        private lateinit var root: View
        private lateinit var recycler: RecyclerView
        private lateinit var clockTv: TextView
        private lateinit var dateTv: TextView
        private lateinit var weatherTv: TextView
        private lateinit var prayerWidget: LinearLayout
        private lateinit var hintTv: TextView
        private var countdownTv: TextView? = null

        private var nextPrayerAt = 0L
        private var nextPrayerName = ""
        private var bgAnimator: ValueAnimator? = null

        private data class AppEntry(val label: String, val pkg: String, val banner: Drawable?, val icon: Drawable?, val launch: Intent)

        private val ACCENT = Color.parseColor("#3D5AFE")
        private val TILE_BG = Color.parseColor("#1B2340")
        private val TILE_STROKE = Color.parseColor("#33406E")
        private val FALLBACK_BG = Color.parseColor("#0D1226")

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            root = findViewById(R.id.root)
            clockTv = findViewById(R.id.clock)
            dateTv = findViewById(R.id.date)
            weatherTv = findViewById(R.id.weather)
            prayerWidget = findViewById(R.id.prayerWidget)
            hintTv = findViewById(R.id.hint)
            recycler = findViewById(R.id.appsRow)
            recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            recycler.clipChildren = false
            recycler.clipToPadding = false

            loadApps()
            recycler.adapter = AppsAdapter()

            findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
            findViewById<View>(R.id.btnWifi).setOnClickListener {
                try { startActivity(Intent("android.settings.WIFI_SETTINGS")) } catch (e: Exception) {}
            }

            startClock()
            refreshWeather()
            refreshPrayer()

            recycler.post {
                (recycler.layoutManager as LinearLayoutManager).findViewByPosition(0)?.requestFocus()
            }
        }

        override fun onBackPressed() {
            if (editMode) { setEdit(false); return }
            super.onBackPressed()
        }

        // ---------- التطبيقات ----------
        private fun loadApps() {
            val pm = packageManager
            val found = LinkedHashMap<String, AppEntry>()
            val cats = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
            for (cat in cats) {
                val qi = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (ri in pm.queryIntentActivities(qi, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || found.containsKey(pkg)) continue
                    val cn = android.content.ComponentName(pkg, ri.activityInfo.name)
                    val banner = try { pm.getActivityBanner(cn) ?: pm.getApplicationBanner(ri.activityInfo.applicationInfo) } catch (e: Exception) { null }
                    val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
                    val label = ri.loadLabel(pm)?.toString() ?: pkg
                    val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
                    found[pkg] = AppEntry(label, pkg, banner, icon, launch)
                }
            }
            entries.clear()
            entries.addAll(found.values)
            entries.add(AppEntry("الإعدادات ⚙", "_settings", null, null, Intent()))
            val order = Prefs.sp(this).getString("order", "") ?: ""
            if (order.isNotBlank()) {
                val rank = order.split(",").mapIndexed { i, p -> p to i }.toMap()
                entries.sortBy { rank[it.pkg] ?: Int.MAX_VALUE }
            }
        }

        private fun saveOrder() =
            Prefs.sp(this).edit().putString("order", entries.joinToString(",") { it.pkg }).apply()

        private fun setEdit(b: Boolean) {
            editMode = b
            hintTv.visibility = if (b) View.VISIBLE else View.GONE
            recycler.adapter?.notifyDataSetChanged()
            if (b) (recycler.layoutManager as LinearLayoutManager).findViewByPosition(0)?.requestFocus()
        }

        private inner class AppsAdapter : RecyclerView.Adapter<AppsAdapter.H>() {
            inner class H(v: View) : RecyclerView.ViewHolder(v) {
                val img: ImageView = v.findViewById(R.id.tileImg)
                val label: TextView = v.findViewById(R.id.tileLabel)
                val tile: View = v
            }

            override fun onCreateViewHolder(p: ViewGroup, t: Int) =
                H(layoutInflater.inflate(R.layout.item_app, p, false))

            override fun getItemCount() = entries.size

            private fun tileBg(fill: Int, stroke: Int, strokeW: Int) =
                GradientDrawable().apply {
                    cornerRadius = 14f
                    setColor(fill)
                    setStroke(strokeW, stroke)
                }

            override fun onBindViewHolder(h: H, pos: Int) {
                val e = entries[pos]
                h.label.text = e.label
                if (e.banner != null) {
                    h.img.setImageDrawable(e.banner)
                    h.img.scaleType = ImageView.ScaleType.CENTER_CROP
                } else {
                    h.img.setImageDrawable(e.icon)
                    h.img.scaleType = ImageView.ScaleType.FIT_CENTER
                }
                h.tile.background = tileBg(TILE_BG, TILE_STROKE, 1)
                h.tile.onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                    v.animate().cancel()
                    if (editMode) {
                        // وضع الترتيب: لا تكبير — بل إطار مضيء واضح بدون تداخل
                        v.animate().scaleX(1f).scaleY(1f).setDuration(120).start()
                        v.alpha = if (has) 1f else 0.55f
                        v.elevation = if (has) 20f else 2f
                        v.background = if (has) tileBg(ACCENT, Color.WHITE, 3)
                                       else tileBg(TILE_BG, TILE_STROKE, 1)
                    } else {
                        v.animate()
                            .scaleX(if (has) 1.14f else 1f)
                            .scaleY(if (has) 1.14f else 1f)
                            .setDuration(160).start()
                        v.alpha = if (has) 1f else 0.82f
                        v.elevation = if (has) 18f else 4f
                        if (has) themeFrom(e)
                    }
                }
                h.tile.setOnClickListener {
                    when {
                        editMode -> {}
                        e.pkg == "_settings" -> showSettings()
                        else -> try { startActivity(e.launch) } catch (ex: Exception) {}
                    }
                }
                h.tile.setOnKeyListener { _, code, _ ->
                    if (!editMode) return@setOnKeyListener false
                    when (code) {
                        KeyEvent.KEYCODE_DPAD_LEFT -> { move(pos, -1); true }
                        KeyEvent.KEYCODE_DPAD_RIGHT -> { move(pos, 1); true }
                        KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { setEdit(false); true }
                        KeyEvent.KEYCODE_BACK -> { setEdit(false); true }
                        KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_DPAD_DOWN -> true
                        else -> true
                    }
                }
            }
        }

        private fun move(pos: Int, dir: Int) {
            val to = pos + dir
            if (to < 0 || to >= entries.size) return
            val e = entries.removeAt(pos)
            entries.add(to, e)
            saveOrder()
            recycler.adapter?.notifyItemMoved(pos, to)
            recycler.post { (recycler.layoutManager as LinearLayoutManager).findViewByPosition(to)?.requestFocus() }
        }

        // ---------- الخلفية المتغيرة (لون التطبيق المحدد) ----------
        private fun themeFrom(e: AppEntry) {
            val d = e.banner ?: e.icon ?: return
            val bmp = toBitmap(d) ?: return
            Palette.from(bmp).generate { pal ->
                val dom = pal?.getDominantColor(FALLBACK_BG) ?: FALLBACK_BG
                val dark = Color.rgb(Color.red(dom) / 4 + 10, Color.green(dom) / 4 + 10, Color.blue(dom) / 4 + 18)
                val from = (root.background as? ColorDrawable)?.color ?: FALLBACK_BG
                bgAnimator?.cancel()
                bgAnimator = ValueAnimator.ofArgb(from, dark).apply {
                    duration = 500
                    addUpdateListener { root.setBackgroundColor(it.animatedValue as Int) }
                    start()
                }
            }
        }

        private fun toBitmap(d: Drawable): Bitmap? = try {
            val w = d.intrinsicWidth.coerceIn(1, 220)
            val h = d.intrinsicHeight.coerceIn(1, 220)
            val b = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val c = Canvas(b)
            d.setBounds(0, 0, w, h)
            d.draw(c)
            b
        } catch (e: Exception) { null }

        // ---------- الساعة والعداد ----------
        private fun startClock() {
            val tick = object : Runnable {
                override fun run() {
                    val now = Calendar.getInstance()
                    clockTv.text = SimpleDateFormat("HH:mm", Locale("ar")).format(now.time)
                    dateTv.text = SimpleDateFormat("EEEE، d MMMM", Locale("ar")).format(now.time)
                    updateCountdown()
                    handler.postDelayed(this, 1000)
                }
            }
            handler.post(tick)
        }

        private fun updateCountdown() {
            val tv = countdownTv ?: return
            val at = nextPrayerAt
            if (at <= 0) { tv.text = ""; return }
            var diff = (at - System.currentTimeMillis()).coerceAtLeast(0)
            val h = diff / 3600000
            val m = diff % 3600000 / 60000
            val s = diff % 60000 / 1000
            tv.text = "⏳ متبقي %02d:%02d:%02d".format(h, m, s)
        }

        // ---------- الطقس ----------
        private fun refreshWeather() {
            Thread {
                val r = Weather.fetch(this)
                runOnUiThread {
                    weatherTv.text = r?.let { "🌡 ${it.temp}° | ${it.city}" } ?: "🌡 —"
                }
            }.start()
        }

        // ---------- الصلاة ----------
        private fun refreshPrayer() {
            Thread {
                val t = Prayer.fetch(this)
                runOnUiThread {
                    if (t == null) {
                        prayerWidget.removeAllViews()
                        val tv = TextView(this).apply {
                            text = "تعذر تحميل المواقيت — تحقق من الإنترنت أو المدينة"
                            setTextColor(Color.parseColor("#FFD479"))
                            textSize = 15f
                        }
                        prayerWidget.addView(tv)
                    } else {
                        val (name, at) = Prayer.nextOf(t)
                        nextPrayerName = name
                        nextPrayerAt = at
                        buildPrayerStrip(t, name)
                        Prayer.scheduleNext(this, t)
                    }
                }
            }.start()
        }

        private fun buildPrayerStrip(t: Prayer.Times, nextName: String) {
            prayerWidget.removeAllViews()
            val list = listOf(
                "الفجر" to t.fajr, "الشروق" to t.sunrise, "الظهر" to t.dhuhr,
                "العصر" to t.asr, "المغرب" to t.maghrib, "العشاء" to t.isha
            )
            for ((n, hm) in list) {
                val isNext = (n == nextName)
                val chip = TextView(this).apply {
                    text = "$n
$hm"
                    setTextColor(if (isNext) Color.WHITE else Color.parseColor("#C8D2F0"))
                    textSize = 13f
                    gravity = Gravity.CENTER
                    background = GradientDrawable().apply {
                        cornerRadius = 20f
                        setColor(if (isNext) ACCENT else Color.parseColor("#151C36"))
                        setStroke(1, if (isNext) Color.WHITE else TILE_STROKE)
                    }
                    setPadding(26, 14, 26, 14)
                }
                prayerWidget.addView(chip, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(6, 0, 6, 0) })
            }
            countdownTv = TextView(this).apply {
                textSize = 15f
                setTextColor(Color.parseColor("#FFD479"))
                setTypeface(null, android.graphics.Typeface.BOLD)
                updateCountdown()
            }
            prayerWidget.addView(countdownTv, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(20, 0, 0, 0) })
        }

        // ---------- الإعدادات ----------
        private fun showSettings() {
            val opts = arrayOf("🔀 ترتيب البلاطات", "🕌 مدينة الطقس والصلاة", "📶 إعدادات الواي فاي", "🖥 إعدادات الشاشة")
            AlertDialog.Builder(this)
                .setTitle("الإعدادات")
                .setItems(opts) { _, which ->
                    when (which) {
                        0 -> setEdit(true)
                        1 -> askCity()
                        2 -> try { startActivity(Intent("android.settings.WIFI_SETTINGS")) } catch (e: Exception) {}
                        3 -> try { startActivity(Intent("android.settings.DISPLAY_SETTINGS")) } catch (e: Exception) {}
                    }
                }.show()
        }

        private fun askCity() {
            val box = EditText(this).apply { setText(Prefs.city(this@HomeActivity)) }
            AlertDialog.Builder(this)
                .setTitle("اسم المدينة بالإنجليزية (مثال: Istanbul)")
                .setView(box)
                .setPositiveButton("حفظ") { _, _ ->
                    val c = box.text.toString().trim()
                    if (c.isNotEmpty()) {
                        Prefs.setCity(this, c)
                        refreshWeather()
                        refreshPrayer()
                    }
                }
                .setNegativeButton("إلغاء", null)
                .show()
        }
    }
