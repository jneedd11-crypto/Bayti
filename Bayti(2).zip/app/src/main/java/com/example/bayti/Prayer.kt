package com.example.bayti

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import org.json.JSONObject
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale

object Prayer {
    data class Times(val fajr: String, val sunrise: String, val dhuhr: String,
                     val asr: String, val maghrib: String, val isha: String, val city: String)

    // method=13 طريقة تركيا (الديانت) — غيّرها إن رغبت من الإعدادات لاحقا
    fun fetch(ctx: Context): Times? {
        val city = Prefs.city(ctx)
        return try {
            val enc = URLEncoder.encode(city, "UTF-8")
            val t = URL("https://api.aladhan.com/v1/timingsByCity?city=$enc&country=&method=13").readText()
            val tm = JSONObject(t).getJSONObject("data").getJSONObject("timings")
            Times(
                tm.getString("Fajr").take(5),
                tm.getString("Sunrise").take(5),
                tm.getString("Dhuhr").take(5),
                tm.getString("Asr").take(5),
                tm.getString("Maghrib").take(5),
                tm.getString("Isha").take(5),
                city
            ).also { save(ctx, it) }
        } catch (e: Exception) {
            cached(ctx)
        }
    }

    fun nextOf(t: Times): Pair<String, Long> {
        val fmt = SimpleDateFormat("HH:mm", Locale.US)
        val now = System.currentTimeMillis()
        val list = listOf(
            "الفجر" to t.fajr, "الشروق" to t.sunrise, "الظهر" to t.dhuhr,
            "العصر" to t.asr, "المغرب" to t.maghrib, "العشاء" to t.isha
        )
        var bestName = ""; var bestAt = Long.MAX_VALUE
        for ((n, hm) in list) {
            val at = atTime(hm, 0)
            if (at > now && at < bestAt) { bestAt = at; bestName = n }
        }
        if (bestName.isEmpty()) { bestAt = atTime(t.fajr, 1); bestName = "الفجر" }
        return bestName to bestAt
    }

    private fun atTime(hhmm: String, addDays: Int): Long {
        val fmt = SimpleDateFormat("HH:mm", Locale.US)
        val cal = Calendar.getInstance()
        cal.add(Calendar.DAY_OF_YEAR, addDays)
        val p = Calendar.getInstance()
        p.time = fmt.parse(hhmm)!!
        cal.set(Calendar.HOUR_OF_DAY, p.get(Calendar.HOUR_OF_DAY))
        cal.set(Calendar.MINUTE, p.get(Calendar.MINUTE))
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)
        return cal.timeInMillis
    }

    fun scheduleNext(ctx: Context, t: Times) {
        val (name, at) = nextOf(t)
        val alarm = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val i = Intent(ctx, PrayerAlertReceiver::class.java).putExtra("name", name)
        val pi = PendingIntent.getBroadcast(
            ctx, 1001, i,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        try {
            if (Build.VERSION.SDK_INT >= 31 && !alarm.canScheduleExactAlarms()) throw SecurityException()
            alarm.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: Exception) {
            alarm.setWindow(AlarmManager.RTC_WAKEUP, at, 5 * 60 * 1000, pi)
        }
        Prefs.sp(ctx).edit().putLong("nextPrayerAt", at).putString("nextPrayerName", name).apply()
    }

    private fun save(ctx: Context, t: Times) = Prefs.sp(ctx).edit().apply {
        putString("p_fajr", t.fajr); putString("p_sunrise", t.sunrise)
        putString("p_dhuhr", t.dhuhr); putString("p_asr", t.asr)
        putString("p_maghrib", t.maghrib); putString("p_isha", t.isha)
        putString("p_city", t.city)
    }.apply()

    private fun cached(ctx: Context): Times? {
        val sp = Prefs.sp(ctx)
        if (!sp.contains("p_fajr")) return null
        return Times(
            sp.getString("p_fajr", "")!!, sp.getString("p_sunrise", "")!!,
            sp.getString("p_dhuhr", "")!!, sp.getString("p_asr", "")!!,
            sp.getString("p_maghrib", "")!!, sp.getString("p_isha", "")!!,
            sp.getString("p_city", "")!!
        )
    }
}
