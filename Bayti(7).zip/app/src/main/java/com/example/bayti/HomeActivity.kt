package com.example.bayti

        import android.app.Dialog
import android.content.Intent
import android.net.Uri
import android.provider.Settings
    import android.content.pm.PackageManager
            import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
        import android.graphics.drawable.Drawable
    import android.graphics.drawable.GradientDrawable
    import android.os.Bundle
    import android.os.Handler
    import android.os.Looper
    import android.view.Gravity
    import android.view.KeyEvent
    import android.view.View
    import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
    import android.widget.Button
    import android.widget.EditText
    import android.widget.ImageView
    import android.widget.LinearLayout
    import android.widget.TextView
        import androidx.appcompat.app.AppCompatActivity
        import androidx.recyclerview.widget.LinearLayoutManager
    import androidx.recyclerview.widget.RecyclerView
    import java.text.SimpleDateFormat
    import java.net.URL
import java.util.Calendar
    import java.util.Locale

    class HomeActivity : AppCompatActivity() {

        private val handler = Handler(Looper.getMainLooper())
        private val entries = mutableListOf<AppEntry>()
        private var editMode = false

        private lateinit var root: View
        private lateinit var recycler: RecyclerView
        private lateinit var clockTv: TextView
        private lateinit var dateTv: TextView
        private lateinit var weatherTv: TextView
        private lateinit var prayerWidget: LinearLayout
        private lateinit var hintTv: TextView
        private var countdownTv: TextView? = null

        private var nextPrayerAt = 0L
        private var nextPrayerName = ""
        private lateinit var bgImage: ImageView
        private lateinit var adhanOverlay: View
        private lateinit var adhanTitle: TextView
        private var lastAdhan = ""
        private var bgBusy = false

        private data class AppEntry(val label: String, val pkg: String, val banner: Drawable?, val icon: Drawable?, val launch: Intent)

        private val ACCENT = Color.parseColor("#3D5AFE")
        private val TILE_BG = Color.parseColor("#1B2340")
        private val TILE_STROKE = Color.parseColor("#33406E")

        override fun onCreate(savedInstanceState: Bundle?) {
            super.onCreate(savedInstanceState)
            setContentView(R.layout.activity_main)
            root = findViewById(R.id.root)
            clockTv = findViewById(R.id.clock)
            dateTv = findViewById(R.id.date)
            weatherTv = findViewById(R.id.weather)
            prayerWidget = findViewById(R.id.prayerWidget)
            hintTv = findViewById(R.id.hint)
            bgImage = findViewById(R.id.bgImage)
            adhanOverlay = findViewById(R.id.adhanOverlay)
            adhanTitle = findViewById(R.id.adhanTitle)
            recycler = findViewById(R.id.appsRow)
            recycler.layoutManager = LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
            recycler.clipChildren = false
            recycler.clipToPadding = false
            recycler.itemAnimator = null  // استبدال فوري بلا طيران وتداخل

            loadApps()
            recycler.adapter = AppsAdapter()

            findViewById<View>(R.id.btnSettings).setOnClickListener { showSettings() }
            findViewById<View>(R.id.btnWifi).setOnClickListener {
                try { startActivity(Intent("android.settings.WIFI_SETTINGS")) } catch (e: Exception) {}
            }

            startClock()
            refreshWeather()
            refreshPrayer()
            scheduleBg(1500)

            recycler.post {
                (recycler.layoutManager as LinearLayoutManager).findViewByPosition(0)?.requestFocus()
            }
        }

        override fun onBackPressed() {
            if (editMode) { setEdit(false); return }
            super.onBackPressed()
        }

        // ---------- التطبيقات ----------
        private fun loadApps() {
            val pm = packageManager
            val found = LinkedHashMap<String, AppEntry>()
            val cats = listOf(Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER)
            for (cat in cats) {
                val qi = Intent(Intent.ACTION_MAIN).addCategory(cat)
                for (ri in pm.queryIntentActivities(qi, 0)) {
                    val pkg = ri.activityInfo.packageName
                    if (pkg == packageName || found.containsKey(pkg)) continue
                    val cn = android.content.ComponentName(pkg, ri.activityInfo.name)
                    val banner = try { pm.getActivityBanner(cn) ?: pm.getApplicationBanner(ri.activityInfo.applicationInfo) } catch (e: Exception) { null }
                    val icon = try { ri.loadIcon(pm) } catch (e: Exception) { null }
                    val label = ri.loadLabel(pm)?.toString() ?: pkg
                    val launch = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setComponent(cn)
                    found[pkg] = AppEntry(label, pkg, banner, icon, launch)
                }
            }
            entries.clear()
            entries.addAll(found.values)
            entries.add(AppEntry("الإعدادات ⚙", "_settings", null, null, Intent()))
            val order = Prefs.sp(this).getString("order", "") ?: ""
            if (order.isNotBlank()) {
                val rank = order.split(",").mapIndexed { i, p -> p to i }.toMap()
                entries.sortBy { rank[it.pkg] ?: Int.MAX_VALUE }
            }
        }

        private fun saveOrder() =
            Prefs.sp(this).edit().putString("order", entries.joinToString(",") { it.pkg }).apply()

        private fun setEdit(b: Boolean, focusPos: Int = 0) {
            editMode = b
            hintTv.visibility = if (b) View.VISIBLE else View.GONE
            if (b) hintTv.text = "حرّك البلاطة المضيئة بالأسهم — OK للحفظ — رجوع للإلغاء"
            // في وضع الترتيب: قصّ صارم — لا تداخل نهائيا
            recycler.clipChildren = !b
            recycler.clipToPadding = !b
            recycler.adapter?.notifyDataSetChanged()
            if (b) recycler.post {
                (recycler.layoutManager as LinearLayoutManager)
                    .findViewByPosition(focusPos.coerceIn(0, entries.size - 1))?.requestFocus()
            }
        }

        private inner class AppsAdapter : RecyclerView.Adapter<AppsAdapter.H>() {
            inner class H(v: View) : RecyclerView.ViewHolder(v) {
                val img: ImageView = v.findViewById(R.id.tileImg)
                val label: TextView = v.findViewById(R.id.tileLabel)
                val tile: View = v
            }

            override fun onCreateViewHolder(p: ViewGroup, t: Int) =
                H(layoutInflater.inflate(R.layout.item_app, p, false))

            override fun getItemCount() = entries.size

            private fun tileBg(fill: Int, stroke: Int, strokeW: Int) =
                GradientDrawable().apply {
                    cornerRadius = 14f
                    setColor(fill)
                    setStroke(strokeW, stroke)
                }

            override fun onBindViewHolder(h: H, pos: Int) {
                val e = entries[pos]
                h.label.text = e.label
                if (e.banner != null) {
                    h.img.setImageDrawable(e.banner)
                    h.img.scaleType = ImageView.ScaleType.CENTER_CROP
                } else {
                    h.img.setImageDrawable(e.icon)
                    h.img.scaleType = ImageView.ScaleType.FIT_CENTER
                }
                h.tile.background = tileBg(TILE_BG, TILE_STROKE, 1)
                h.tile.onFocusChangeListener = View.OnFocusChangeListener { v, has ->
                    v.animate().cancel()
                    if (editMode) {
                        // وضع الترتيب: لا تكبير — بل إطار مضيء واضح بدون تداخل
                        v.animate().scaleX(1f).scaleY(1f).setDuration(100).start()
                        v.alpha = if (has) 1f else 0.55f
                        v.elevation = 0f
                        v.background = if (has) tileBg(ACCENT, Color.WHITE, 3)
                                       else tileBg(TILE_BG, TILE_STROKE, 1)
                    } else {
                        v.animate()
                            .scaleX(if (has) 1.15f else 1f)
                            .scaleY(if (has) 1.15f else 1f)
                            .setDuration(220)
                            .setInterpolator(OvershootInterpolator(1.35f))
                            .start()
                        v.alpha = if (has) 1f else 0.82f
                        v.elevation = if (has) 22f else 4f
                    }
                }
                h.tile.setOnClickListener {
                    if (h.tile.tag == "long") { h.tile.tag = null; return@setOnClickListener }
                    when {
                        editMode -> {}
                        e.pkg == "_settings" -> showSettings()
                        else -> try { startActivity(e.launch) } catch (ex: Exception) {}
                    }
                }
                h.tile.setOnKeyListener { v, code, event ->
                    val cur = h.bindingAdapterPosition
                    if (cur == RecyclerView.NO_POSITION) return@setOnKeyListener true
                    when {
                        editMode -> when (code) {
                            KeyEvent.KEYCODE_DPAD_LEFT -> { move(cur, -1); true }
                            KeyEvent.KEYCODE_DPAD_RIGHT -> { move(cur, 1); true }
                            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { setEdit(false); true }
                            KeyEvent.KEYCODE_BACK -> { setEdit(false); true }
                            else -> true
                        }
                        (code == KeyEvent.KEYCODE_DPAD_CENTER || code == KeyEvent.KEYCODE_ENTER) -> {
                            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0) v.tag = null
                            if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 8) {
                                // ضغطة مطوّلة (~ثانية): خيارات البلاطة
                                v.tag = "long"
                                val p = h.bindingAdapterPosition
                                if (p != RecyclerView.NO_POSITION) showTileOptions(p)
                                true
                            } else false
                        }
                        else -> false
                    }
                }
            }
        }

        private fun move(pos: Int, dir: Int) {
            val to = pos + dir
            if (to < 0 || to >= entries.size) return
            val e = entries.removeAt(pos)
            entries.add(to, e)
            saveOrder()
            recycler.adapter?.notifyItemMoved(pos, to)
            recycler.post { (recycler.layoutManager as LinearLayoutManager).findViewByPosition(to)?.requestFocus() }
        }

        // ---------- الساعة والعداد ----------
        private fun startClock() {
            val tick = object : Runnable {
                override fun run() {
                    val now = Calendar.getInstance()
                    clockTv.text = SimpleDateFormat("HH:mm", Locale("ar")).format(now.time)
                    dateTv.text = SimpleDateFormat("EEEE، d MMMM", Locale("ar")).format(now.time)
                    updateCountdown()
                    handler.postDelayed(this, 1000)
                }
            }
            handler.post(tick)
        }

        private fun updateCountdown() {
            val tv = countdownTv ?: return
            val at = nextPrayerAt
            if (at <= 0) { tv.text = ""; return }
            var diff = (at - System.currentTimeMillis()).coerceAtLeast(0)
            // انتهى العداد: أظهر شاشة الأذان مرة واحدة لكل صلاة
            if (diff == 0L && nextPrayerName.isNotEmpty() && lastAdhan != nextPrayerName) {
                lastAdhan = nextPrayerName
                showAdhan(nextPrayerName)
                refreshPrayer()
            }
            val h = diff / 3600000
            val m = diff % 3600000 / 60000
            val s = diff % 60000 / 1000
            tv.text = "⏳ متبقي %02d:%02d:%02d".format(h, m, s)
        }

        // ---------- الطقس ----------
        private fun refreshWeather() {
            Thread {
                val r = Weather.fetch(this)
                runOnUiThread {
                    weatherTv.text = r?.let { "🌡 ${it.temp}° | ${it.city}" } ?: "🌡 —"
                }
            }.start()
        }

        // ---------- الصلاة ----------
        private fun refreshPrayer() {
            Thread {
                val t = Prayer.fetch(this)
                runOnUiThread {
                    if (t == null) {
                        prayerWidget.removeAllViews()
                        val tv = TextView(this).apply {
                            text = "تعذر تحميل المواقيت — تحقق من الإنترنت أو المدينة"
                            setTextColor(Color.parseColor("#FFD479"))
                            textSize = 15f
                        }
                        prayerWidget.addView(tv)
                    } else {
                        val (name, at) = Prayer.nextOf(t)
                        nextPrayerName = name
                        nextPrayerAt = at
                        buildPrayerStrip(t, name)
                        Prayer.scheduleNext(this, t)
                    }
                }
            }.start()
        }

        private fun buildPrayerStrip(t: Prayer.Times, nextName: String) {
            prayerWidget.removeAllViews()
            val list = listOf(
                "الفجر" to t.fajr, "الشروق" to t.sunrise, "الظهر" to t.dhuhr,
                "العصر" to t.asr, "المغرب" to t.maghrib, "العشاء" to t.isha
            )
            for ((n, hm) in list) {
                val isNext = (n == nextName)
                val chip = TextView(this).apply {
                text = "$n\n$hm"
                    setTextColor(if (isNext) Color.WHITE else Color.parseColor("#C8D2F0"))
                    textSize = 13f
                    gravity = Gravity.CENTER
                    background = GradientDrawable().apply {
                        cornerRadius = 20f
                        setColor(if (isNext) ACCENT else Color.parseColor("#151C36"))
                        setStroke(1, if (isNext) Color.WHITE else TILE_STROKE)
                    }
                    setPadding(26, 14, 26, 14)
                }
                prayerWidget.addView(chip, LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
                ).apply { setMargins(6, 0, 6, 0) })
            }
            countdownTv = TextView(this).apply {
                textSize = 15f
                setTextColor(Color.parseColor("#FFD479"))
                setTypeface(null, android.graphics.Typeface.BOLD)
                updateCountdown()
            }
            prayerWidget.addView(countdownTv, LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { setMargins(20, 0, 0, 0) })
        }

        // ---------- نوافذ التلفاز الخاصة (أزرار مضيئة بالتركيز) ----------
    private fun tvBtn(label: String, dlg: Dialog, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label; textSize = 17f; isAllCaps = false
            setTextColor(Color.WHITE)
            setPadding(30, 18, 30, 18)
            background = GradientDrawable().apply {
                cornerRadius = 14f
                setColor(Color.parseColor("#1F2A4D"))
            }
            setOnFocusChangeListener { v, has ->
                v.animate().cancel()
                v.animate().scaleX(if (has) 1.05f else 1f).scaleY(if (has) 1.05f else 1f)
                    .setDuration(120).start()
                background = GradientDrawable().apply {
                    cornerRadius = 14f
                    setColor(if (has) Color.parseColor("#3D5AFE") else Color.parseColor("#1F2A4D"))
                    setStroke(2, if (has) Color.WHITE else Color.parseColor("#33406E"))
                }
            }
            setOnClickListener { onClick(); dlg.dismiss() }
        }

    private fun tvDialog(title: String, items: List<Pair<String, () -> Unit>>) {
        val dlg = Dialog(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 34, 44, 34)
        }
        container.addView(TextView(this).apply {
            text = title; textSize = 21f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 26)
        })
        for ((label, act) in items) {
            container.addView(tvBtn(label, dlg, act),
                LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
                    .apply { setMargins(0, 8, 0, 8) })
        }
        dlg.setContentView(container)
        dlg.window?.setBackgroundDrawable(GradientDrawable().apply {
            cornerRadius = 22f
            setColor(Color.parseColor("#151C36"))
            setStroke(2, Color.parseColor("#33406E"))
        })
        dlg.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.42).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dlg.show()
        container.post { container.getChildAt(1)?.requestFocus() }
    }

    // ---------- خلفية طبيعة متبدلة ----------
    private fun scheduleBg(delay: Long) {
        handler.postDelayed({
            if (!bgBusy) {
                bgBusy = true
                Thread {
                    val bmp = fetchNature()
                    bgBusy = false
                    runOnUiThread {
                        if (bmp != null) {
                            bgImage.setImageBitmap(bmp)
                            bgImage.alpha = 0f
                            bgImage.animate().alpha(1f).setDuration(1000).start()
                        }
                        scheduleBg(6 * 60 * 1000L)
                    }
                }.start()
            } else scheduleBg(60_000)
        }, delay)
    }

    private fun fetchNature(): Bitmap? = try {
        val u = URL("https://picsum.photos/1280/720?random=" + System.currentTimeMillis())
        BitmapFactory.decodeStream(u.openConnection().getInputStream())
    } catch (e: Exception) { null }

    // ---------- شاشة الأذان ----------
    private fun showAdhan(name: String) {
        adhanTitle.text = "حان الآن وقت صلاة $name"
        adhanOverlay.visibility = View.VISIBLE
        adhanOverlay.alpha = 0f
        adhanOverlay.animate().alpha(1f).setDuration(1400).start()
        handler.postDelayed({ hideAdhan() }, 12 * 60 * 1000L)
    }

    private fun hideAdhan() {
        adhanOverlay.animate().alpha(0f).setDuration(1400)
            .withEndAction { adhanOverlay.visibility = View.GONE }.start()
    }

    // ---------- الإعدادات ----------
    private fun showSettings() {
        tvDialog("الإعدادات", listOf(
            "🕌 مدينة الطقس والصلاة" to { askCity() },
            "⚙️ إعدادات النظام" to { try { startActivity(Intent(Settings.ACTION_SETTINGS)) } catch (e: Exception) {} },
            "📶 إعدادات الواي فاي" to { try { startActivity(Intent("android.settings.WIFI_SETTINGS")) } catch (e: Exception) {} },
            "🖥 إعدادات الشاشة" to { try { startActivity(Intent("android.settings.DISPLAY_SETTINGS")) } catch (e: Exception) {} }
        ))
    }

    // خيارات البلاطة بالضغط المطوّل
    private fun showTileOptions(pos: Int) {
        val e = entries[pos]
        tvDialog(e.label, listOf(
            "🔀 تحريك البلاطة" to { setEdit(true, pos) },
            "ℹ️ معلومات التطبيق" to {
                try {
                    startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        Uri.parse("package:${e.pkg}")))
                } catch (ex: Exception) {}
            }
        ))
    }

    private fun askCity() {
        val dlg = Dialog(this)
        val container = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(44, 34, 44, 34)
        }
        container.addView(TextView(this).apply {
            text = "اسم المدينة بالإنجليزية"; textSize = 20f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 20)
        })
        val box = EditText(this).apply {
            setText(Prefs.city(this@HomeActivity))
            setTextColor(Color.WHITE)
            setHintTextColor(Color.GRAY)
        }
        container.addView(box)
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        row.addView(tvBtn("حفظ", dlg) {
            val c = box.text.toString().trim()
            if (c.isNotEmpty()) {
                Prefs.setCity(this, c)
                refreshWeather()
                refreshPrayer()
            }
        }, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(0, 20, 8, 0) })
        row.addView(tvBtn("إلغاء", dlg) {},
            LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f).apply { setMargins(8, 20, 0, 0) })
        container.addView(row)
        dlg.setContentView(container)
        dlg.window?.setBackgroundDrawable(GradientDrawable().apply {
            cornerRadius = 22f
            setColor(Color.parseColor("#151C36"))
            setStroke(2, Color.parseColor("#33406E"))
        })
        dlg.window?.setLayout(
            (resources.displayMetrics.widthPixels * 0.42).toInt(),
            ViewGroup.LayoutParams.WRAP_CONTENT
        )
        dlg.show()
        container.post { box.requestFocus() }
    }
}
